// hello.cpp by Bill Weinman [bw.org]
// updated 2022-05-19
#include <iostream>

int main() {
    std::cout << "Hello, World!\n";
    return 0;
}
