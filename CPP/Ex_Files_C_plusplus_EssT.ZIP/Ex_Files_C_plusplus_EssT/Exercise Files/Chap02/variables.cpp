// variables.cpp by Bill Weinman [bw.org]
// updated 2022-06-12
#include <format>
#include <iostream>

using std::format;
using std::cout;

int main() {
    int i {};
    cout << format("i is {}\n", i);
}
